/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

/**
 *
 * @author Aimar
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import modelo.KotxeModelo;

public class Query {

    Connection conn;
    Konexioa connect = new Konexioa();

    public Query() {
        conn = connect.conectar();
    }

    public ObservableList<KotxeModelo> datuakSelect() {
        ObservableList<KotxeModelo> cars = FXCollections.observableArrayList();
        try {
            int id, cantPuertas;
            String marca, modelo, matricula;
            PreparedStatement ps;
            ResultSet rs;
            String sql = "SELECT * FROM kotxeak";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                id = rs.getInt("id");
                marca = rs.getString("marca");
                modelo = rs.getString("modelo");
                matricula = rs.getString("matricula");
                cantPuertas = rs.getInt("cant_puertas");
                KotxeModelo car = new KotxeModelo(id, marca, modelo, matricula, cantPuertas);
                cars.add(car);
            }
            rs.close();
            ps.close();
            return cars;
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cars;
    }

    public void datuakInsertatu(String marca, String modelo, String matricula, int cantPuertas) throws SQLException {
        String sql = "INSERT INTO kotxeak (marca,modelo,matricula,cant_puertas) VALUES(?,?,?,?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, marca);
        pstmt.setString(2, modelo);
        pstmt.setString(3, matricula);
        pstmt.setInt(4, cantPuertas);
        pstmt.executeUpdate();
        pstmt.close();
    }

    public void datuakEzabatu(KotxeModelo car) throws SQLException {
        String sql = "DELETE FROM kotxeak WHERE id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, car.getId());
        pstmt.executeUpdate();
        pstmt.close();
    }

    public void datuakAldatu(KotxeModelo kotxe) throws SQLException {
        PreparedStatement updateSententzia = null;
        ResultSet rs = null;
        String urla = "";

        String sql = "UPDATE kotxeak SET "
                + "marca = ?,"
                + "modelo = ?,"
                + "matricula = ?,"
                + "cant_puertas = ?"
                + "WHERE id = ?";

        updateSententzia = conn.prepareStatement(sql);

        updateSententzia.setInt(5, kotxe.getId());
        updateSententzia.setString(1, kotxe.getMarca());
        updateSententzia.setString(2, kotxe.getModelo());
        updateSententzia.setString(3, kotxe.getMatricula());
        updateSententzia.setInt(4, kotxe.getCantPuertas());
        int erregistroAldatuak = updateSententzia.executeUpdate();

    }
}
