/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.Query;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JOptionPane;
import java.lang.NumberFormatException;
import modelo.KotxeModelo;

/**
 *
 * @author Aimar
 */
public class KotxeVista extends Application {

    public Button add, update, delete;

    @Override
    public void start(Stage primaryStage) throws SQLException, NullPointerException {

        TableView<KotxeModelo> table = new TableView<>();

        Label label = new Label("Autoak");
        Query dboh = new Query();

        table.setEditable(true);
        table.setItems(dboh.datuakSelect());

        TableColumn<KotxeModelo, Integer> idCol = new TableColumn<>("Id");
        idCol.setMinWidth(100);
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setCellFactory(TextFieldTableCell.<KotxeModelo, Integer>forTableColumn(new IntegerStringConverter()));
        idCol.setOnEditCommit((TableColumn.CellEditEvent<KotxeModelo, Integer> t) -> {
                    ((KotxeModelo) t.getTableView().getItems().get(
                            t.getTablePosition().getRow())).setId(t.getNewValue());
                });

        TableColumn<KotxeModelo, String> marcaCol = new TableColumn<>("Marka");
        marcaCol.setMinWidth(100);
        marcaCol.setCellValueFactory(new PropertyValueFactory<>("marca"));
        marcaCol.setCellFactory(TextFieldTableCell.<KotxeModelo>forTableColumn());
        marcaCol.setOnEditCommit((TableColumn.CellEditEvent<KotxeModelo, String> t) -> {
            ((KotxeModelo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())).setMarca(t.getNewValue());
            System.out.println("Izena aldatu duzu: " + t.getOldValue() + " => " + t.getNewValue());
        });

        TableColumn<KotxeModelo, String> modeloCol = new TableColumn<>("Modeloa");
        modeloCol.setMinWidth(100);
        modeloCol.setCellValueFactory(new PropertyValueFactory<>("modelo"));
        modeloCol.setCellFactory(TextFieldTableCell.<KotxeModelo>forTableColumn());
        modeloCol.setOnEditCommit((TableColumn.CellEditEvent<KotxeModelo, String> t) -> {
            ((KotxeModelo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())).setModelo(t.getNewValue());
            System.out.println("Izena aldatu duzu: " + t.getOldValue() + " => " + t.getNewValue());
        });

        TableColumn<KotxeModelo, String> matriculaCol = new TableColumn<>("Matrikula");
        matriculaCol.setMinWidth(100);
        matriculaCol.setCellValueFactory(new PropertyValueFactory<>("matricula"));
        matriculaCol.setCellFactory(TextFieldTableCell.<KotxeModelo>forTableColumn());
        matriculaCol.setOnEditCommit((TableColumn.CellEditEvent<KotxeModelo, String> t) -> {
            ((KotxeModelo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())).setMatricula(t.getNewValue());
            System.out.println("Izena aldatu duzu: " + t.getOldValue() + " => " + t.getNewValue());
        });

        TableColumn<KotxeModelo, Integer> numDoorCol = new TableColumn<>("Ate Kopurua");
        numDoorCol.setMinWidth(170);
        numDoorCol.setCellValueFactory(new PropertyValueFactory<>("cantPuertas"));
        numDoorCol.setCellFactory(TextFieldTableCell.<KotxeModelo, Integer>forTableColumn(new IntegerStringConverter()));
        numDoorCol.setOnEditCommit((TableColumn.CellEditEvent<KotxeModelo, Integer> t) -> {
                    ((KotxeModelo) t.getTableView().getItems().get(
                            t.getTablePosition().getRow())).setCantPuertas(t.getNewValue());
                });

        table.getColumns().addAll(idCol, marcaCol, modeloCol, matriculaCol, numDoorCol);

        TextField addMarca = new TextField();
        addMarca.setPromptText("Marka");
        addMarca.setMaxWidth(marcaCol.getPrefWidth());

        TextField addModelo = new TextField();
        addModelo.setMaxWidth(modeloCol.getPrefWidth());
        addModelo.setPromptText("Modeloa");

        TextField addMatricula = new TextField();
        addMatricula.setMaxWidth(matriculaCol.getPrefWidth());
        addMatricula.setPromptText("Matrikula");

        TextField addCantPuertas = new TextField();
        addCantPuertas.setMaxWidth(numDoorCol.getPrefWidth());
        addCantPuertas.setPromptText("Ate Kopurua");
        addCantPuertas.setMinWidth(150);

        add = new Button("Gehitu");

        add.setOnAction((ActionEvent e) -> {

                    if (addMarca.getText().equals("") || addModelo.getText().equals("") || addMatricula.getText().equals("") || addCantPuertas.getText().equals("")) {
                        JOptionPane.showMessageDialog(null, "Kanporen bat utzik dago");
                    } else {
                        try {
                            dboh.datuakInsertatu(addMarca.getText(), addModelo.getText(), addMatricula.getText(), Integer.parseInt(addCantPuertas.getText()));

                            addMarca.clear();
                            addModelo.clear();
                            addMatricula.clear();
                            addCantPuertas.clear();
                            table.setItems(dboh.datuakSelect());
                            JOptionPane.showMessageDialog(null, "Kotxe berri bat sartu da");
                        } catch (SQLException ex) {
                            Logger.getLogger(KotxeVista.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (NumberFormatException nfe) {
                            JOptionPane.showMessageDialog(null, "Zenbakiak soilik, letrarik ez da onartzen Ate Kopuruan");
                        }

                    }
                }
        );

        delete = new Button("Ezabatu");
        delete.setOnAction((ActionEvent e) -> {
                    if (table.getSelectionModel().getSelectedItem() == null) {
                        JOptionPane.showMessageDialog(null, "Ez da ezabatzeko ezer aukeratu");
                    } else {
                        try {
                            KotxeModelo kotxe = table.getSelectionModel().getSelectedItem();
                            dboh.datuakEzabatu(kotxe);
                            table.setItems(dboh.datuakSelect());
                            JOptionPane.showMessageDialog(null, "Aukeratutako kotxea ezabatu da");
                        } catch (SQLException ex) {
                            Logger.getLogger(KotxeVista.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                });

        update = new Button("Aldatu");
        
//        Kotxea aldatzeko orduan lehendabizi Tableviewan bat aukeratu, 
//        ondoren aldatu nahi duzun kanpoa beheko textfieldean idatzi beher duzu 
//                eta azkenik "Aldatu" botoiari eman

        update.setOnAction((ActionEvent e) -> { 
                    if (table.getSelectionModel().getSelectedItem() == null) {
                        JOptionPane.showMessageDialog(null, "Ez da aldatzeko ezer aukeratu");

                    } else {

                        KotxeModelo kotxe = table.getSelectionModel().getSelectedItem();
                        if (addMarca.getText().equals("")) {
                            kotxe.setMarca(kotxe.getMarca());
                        } else {
                            kotxe.setMarca(addMarca.getText());
                        }
                        if (addModelo.getText().equals("")) {
                            kotxe.setModelo(kotxe.getModelo());
                        } else {
                            kotxe.setModelo(addModelo.getText());
                        }
                        if (addMatricula.getText().equals("")) {
                            kotxe.setMatricula(kotxe.getMatricula());
                        } else {
                            kotxe.setMatricula(addMatricula.getText());
                        }
                        if (addCantPuertas.getText().equals("")) {
                            kotxe.setCantPuertas(kotxe.getCantPuertas());
                        } else {
                            kotxe.setCantPuertas(Integer.parseInt(addCantPuertas.getText()));
                        }

                        addMarca.clear();
                        addModelo.clear();
                        addMatricula.clear();
                        addCantPuertas.clear();

                        try {
                            dboh.datuakAldatu(kotxe);
                        } catch (SQLException ex) {
                            Logger.getLogger(KotxeVista.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        JOptionPane.showMessageDialog(null, "Aukeratutako kotxean aldaketak egin dituzu");
                        table.setItems(dboh.datuakSelect());
//                        }
                    }
                });

        HBox hb = new HBox();

        hb.getChildren().addAll(addMarca, addModelo, addMatricula, addCantPuertas, add, update, delete);
        hb.setSpacing(3);
        VBox rootBox = new VBox();

        rootBox.setSpacing(5);
        rootBox.setPadding(new Insets(10, 10, 10, 10));
        rootBox.getChildren().addAll(label, table, hb);
        rootBox.setStyle("-fx-background-color: lightblue ;");
        Scene scene = new Scene(rootBox, 725, 460);

        primaryStage.setTitle("Kotxe desberdinen datuen tabla ");
        primaryStage.setScene(scene);
        label.setFont(new Font("Arial", 20));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
