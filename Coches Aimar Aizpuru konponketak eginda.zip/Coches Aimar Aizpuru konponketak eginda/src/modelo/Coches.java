/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author DM3-2-02
 */
public class Coches implements Serializable {

    StringProperty marca = new SimpleStringProperty();
    StringProperty modelo = new SimpleStringProperty();
    StringProperty matricula = new SimpleStringProperty();
    IntegerProperty quantPuertas = new SimpleIntegerProperty();
    BooleanProperty familiar = new SimpleBooleanProperty();

    public Coches() {
    }
    
    

    public Coches(String marca, String modelo, String matricula, int quantPuertas, boolean familiar) {
        this.marca= new SimpleStringProperty(marca);
        this.modelo= new SimpleStringProperty(modelo);
        this.matricula= new SimpleStringProperty(matricula);
        this.quantPuertas= new SimpleIntegerProperty(quantPuertas);
        this.familiar= new SimpleBooleanProperty(familiar);
    }
    
    

    public StringProperty marcaProperty() {
        return marca;
    }

    public java.lang.String getMarca() {
        return this.marcaProperty().get();
    }

    public void setMarca(java.lang.String marca) {
        this.marcaProperty().set(marca);
    }

    public StringProperty modeloProperty() {
        return modelo;
    }

    public java.lang.String getModelo() {
        return this.modeloProperty().get();
    }

    public void setModelo(java.lang.String modelo) {
        this.modeloProperty().set(modelo);
    }

    public StringProperty matriculaProperty() {
        return matricula;
    }

    public java.lang.String getMatricula() {
        return this.matriculaProperty().get();
    }

    public void setMatricula(java.lang.String matricula) {
        this.matriculaProperty().set(matricula);
    }

    public IntegerProperty quantDoorProperty() {
        return quantPuertas;
    }

    public java.lang.Integer getQuantPuertas() {
        return this.quantDoorProperty().get();
    }

    public void setQuantPuertas(java.lang.Integer quantPuertas) {
        this.quantDoorProperty().set(quantPuertas);
    }

    public BooleanProperty familiarProperty() {
        return familiar;
    }

    public java.lang.Boolean getFamiliar() {
        return this.familiarProperty().get();
    }

    public void setFamiliar(java.lang.Boolean familiar) {
        this.familiarProperty().set(familiar);
    }

    public String escrbirDatos() {
        return getMarca() + ","+getModelo()+ ","+ getMatricula()+ "," + getQuantPuertas().toString()+ "," + getFamiliar().toString();
    }

}
